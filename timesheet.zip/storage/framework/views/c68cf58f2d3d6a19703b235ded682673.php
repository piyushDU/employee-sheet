
<?php $__env->startSection('content'); ?>
<div class="container mx-auto p-4">
    <h1 class="text-2xl font-semibold mb-4">Your Timesheet</h1>

    <div class="bg-white shadow-md rounded-lg p-6 mb-6">
        <h2 class="text-xl font-semibold mb-3">Timesheet Entries</h2>
        <?php if($timesheets->isEmpty()): ?>
            <p class="text-gray-500">No timesheet entries found.</p>
        <?php else: ?>
            <ul class="space-y-4">
                <?php $__currentLoopData = $timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="border border-gray-200 rounded-lg p-4">
                        <div class="mb-2">
                            <strong class="text-gray-700">Start:</strong> 
                            <?php echo e($timesheet->start_time); ?>

                        </div>
                        <div class="mb-2">
                            <strong class="text-gray-700">Break Start:</strong> 
                            <?php echo e($timesheet->break_start_time); ?>

                        </div>
                        <div class="mb-2">
                            <strong class="text-gray-700">Break End:</strong> 
                            <?php echo e($timesheet->break_end_time); ?>

                        </div>
                        <div class="mb-2">
                            <strong class="text-gray-700">End:</strong> 
                            <?php echo e($timesheet->end_time); ?>

                        </div>
                        <div>
                            <strong class="text-gray-700">Total:</strong> 
                            <?php echo e($timesheet->start_time->diffInMinutes($timesheet->end_time)); ?> minutes
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </div>
    <form action="<?php echo e(route('employee.clockIn')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Clock In</button>
    </form>
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\timesheet\resources\views/employee/index.blade.php ENDPATH**/ ?>