

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1><?php echo e($user->name); ?>'s Timesheet</h1>
    <ul>
        <?php $__currentLoopData = $user->timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                Start: <?php echo e($timesheet->start_time); ?> <br>
                Break Start: <?php echo e($timesheet->break_start_time); ?> <br>
                Break End: <?php echo e($timesheet->break_end_time); ?> <br>
                End: <?php echo e($timesheet->end_time); ?> <br>
                Total: <?php echo e($timesheet->start_time->diffInMinutes($timesheet->end_time)); ?> minutes
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\timesheet\resources\views/admin/show.blade.php ENDPATH**/ ?>